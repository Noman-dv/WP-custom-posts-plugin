=== WP Change Custom Posts Slugs ===
Tags: WP Change Custom Posts Slugs, custom slugs, custom post types
Tested up to: 5.5.1
Donate link: https://greelogix.com
Contributors: firdousi, greelogix

== Description ==


The plugin allows to can easily change slug of custom post types from WordPress admin panel.
Email us: abuzer@greelogix.com

== OUR SERVICES ==
Project                                     Duration                Cost
Woocommerce custom shop                     1d                      $240
Responsiveness for 8 pages website              2d                          $400
WPML configuration for multi-lang website       4h                          $120
Fashion magazine website with Avada theme       5d                          $1000
LawFirm website with Avada theme                5d                          $1000




== Installation ==
- Install and Activate Plugin
- Go to Setting > TH Custom Slugs
- Change the slug of registered post types
- Click on Save Changes button






== Changelog ==
= 1.0 =
* Initial release
